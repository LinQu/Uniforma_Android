package id.ac.astra.polytechnic.kelompok1.p5m_new.viewmodel;

import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

import id.ac.astra.polytechnic.kelompok1.p5m_new.model.Mahasiswa;

public class MahasiswaListViewModel extends ViewModel {

   private List<Mahasiswa> mMahasiswa;

    public List<Mahasiswa> getMahasiswa(){
       if(mMahasiswa == null){
          mMahasiswa = new ArrayList<>();
          loadMahasiswa();
       }
       return mMahasiswa;
    }

    public void loadMahasiswa(){
       for (int i=0; i <100; i++){
          Mahasiswa mahasiswa = new Mahasiswa();
          mahasiswa.setName("Mhs"+i);
          mMahasiswa.add(mahasiswa);
       }
    }
}