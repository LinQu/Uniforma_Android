package id.ac.astra.polytechnic.kelompok1.p5m_new.model;


public class Mahasiswa {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
